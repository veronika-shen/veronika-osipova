<?php

/**@var PDO $pdo */
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/project-links/db.php';
$getLinks = $pdo->query('SELECT * FROM links')->fetchAll(PDO::FETCH_ASSOC);
$shortLink = $_GET['shortLink'] ?? '';
$fullLink = $_GET['fullLink'] ?? '';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Сокращение ссылок</title>
</head>
<body>
    <h1>Сокращение ссылок</h1>
    <form action="short-link.php" method="post">
        <input type="text" name="full-link" placeholder="Вставьте полную ссылку">
        <input type="submit" value="Сократить">
    </form>
    <p>Сокращенная ссылка:<a href="<?= $fullLink ?>"><?= $shortLink ?></a></p>

</body>
</html>