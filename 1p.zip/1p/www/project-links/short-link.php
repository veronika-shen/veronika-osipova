<?php 
/** @var PDO $pdo */
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/project-links/db.php';
$getLinks = $pdo->query('SELECT * FROM links')->fetchAll(PDO::FETCH_ASSOC);

$fullLink = $_POST['full-link'];
$shortCode = substr(md5($fullLink), 0, 6);
$shortLink = "http://$shortCode";

$findlink = $pdo->query("SELECT * FROM links WHERE short_link ='$shortLink'");

if($findlink->rowCount()<1){
    $newLink = $pdo->query("INSERT into links(full_link, short_link) VALUES ('$fullLink', '$shortLink')");
}

header("Location:/project-links/?shortLink=$shortLink&fullLink=$fullLink");